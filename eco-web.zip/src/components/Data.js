import React from 'react'
import '../App.css'
import Count from './Count'

export default function Data() {
  return (
    <div className='data'>
      <p className="orange">SNEAKER COMPANY</p>
      <p className="bold1">Fall Limited Edition Sneakers</p>
      <p className="text">These low-profile sneakers are your perfect casual wear companion. Featuring a durable rubber outer sole, they'll withstand everything the weather can offer.</p>
      
      <p className="wrap">
      <span className="price">$125.00</span>
      <span className='off'>50%</span>
      <b className="cut">$250.00</b>
      </p>
      <Count/>
    </div>
  )
}
