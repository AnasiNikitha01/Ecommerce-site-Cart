import React, { useState } from 'react'
import image1 from './images/image-product-1.jpg'
import image2 from './images/image-product-2.jpg'
import image3 from './images/image-product-3.jpg'
import image4 from './images/image-product-4.jpg'
import image_1 from './images/image-product-1-thumbnail.jpg'
import image_2 from './images/image-product-2-thumbnail.jpg'
import image_3 from './images/image-product-3-thumbnail.jpg'
import image_4 from './images/image-product-4-thumbnail.jpg'
import '../App.css'


export default function Display() {

    const [ImageUrl,setImageUrl] = useState(image1);
   
    const [Style1,setStyle1] = useState({border:'3px solid orange',opacity:'0.5'});
    const [Style2,setStyle2] = useState({border:'none',opacity:'1'});
    const [Style3,setStyle3] = useState({border:'none',opacity:'1'});
    const [Style4,setStyle4] = useState({border:'none',opacity:'1'});

    
    const open_image=(image)=>{
        setImageUrl(image);
      
        if(image===image1){
             setStyle1({border:'3px solid orange',opacity:'0.5'});
             setStyle2({border:'none',opacity:'1'});
             setStyle3({border:'none',opacity:'1'});
             setStyle4({border:'none',opacity:'1'});
        }
        else if(image===image2){
            setStyle1({border:'none',opacity:'1'});
            setStyle3({border:'none',opacity:'1'});
            setStyle4({border:'none',opacity:'1'});
            setStyle2({border:'3px solid orange',opacity:'0.5'});
        }
        else if(image===image3){
            setStyle1({border:'none',opacity:'1'});
            setStyle2({border:'none',opacity:'1'});
            setStyle4({border:'none',opacity:'1'});
            setStyle3({border:'3px solid orange',opacity:'0.5'});
        }
        else if(image===image4){
            setStyle1({border:'none',opacity:'1'});
            setStyle3({border:'none',opacity:'1'});
            setStyle2({border:'none',opacity:'1'});
            setStyle4({border:'3px solid orange',opacity:'0.5'});
        }
        
    }
   
     return (
    <div className='display'>
       <div className="image1">
       <img src={ImageUrl} alt="img1" />
       </div>

       <div className='thumnails'>
       <button id='btn-1' style={Style1} onClick={()=>open_image(image1)} ><img id='img1' src={image_1} alt="img2" /></button>
       <button id='btn-2' style={Style2} onClick={()=>open_image(image2)} ><img id='img2' src={image_2} alt="" /></button>
       <button id='btn-3' style={Style3} onClick={()=>open_image(image3)} ><img id='img3' src={image_3} alt="" /></button>
       <button id='btn-4' style={Style4} onClick={()=>open_image(image4)} ><img id='img4' src={image_4} alt="" /></button>
       
       </div>
    </div>

  )
}
