import React from 'react';
import avtar from './images/avatar.png';
import '../App.css';


export default function Navbar() {
  return (
    <div>
      <nav>
        <span className='title'>
          <span className='title_name'>sneakers</span>

          <div className="dropdown">
            <button className="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Menu
            </button>
            <ul className="dropdown-menu">
              <li><a className="dropdown-item" href="#">Collections</a></li>
              <li><a className="dropdown-item" href="#">Men</a></li>
              <li><a className="dropdown-item" href="#">Women</a></li>
              <li><a className="dropdown-item" href="#">About</a></li>
              <li><a className="dropdown-item" href="#">Contact</a></li>
            </ul>
          </div>

          <ul className='ul1'>
            <li>Collections</li>
            <li>Men</li>
            <li>Women</li>
            <li>About</li>
            <li>Contact</li>
          </ul>
        </span>

        <ul className="ul2">
          <li><i className="bi bi-cart3"></i></li>
          <li><img className='avtar' src={avtar} alt="avtar" /></li>
        </ul>

      </nav>
    </div>
  )
}
