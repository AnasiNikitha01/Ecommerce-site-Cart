import React, { useState } from 'react'
import '../App.css'

export default function Count() {
    const [count,setcount] = useState(0);
    const decrement=()=>{
        if(count===0){
            setcount(0)
        }
        else{
        setcount(count-1)
         }
         }
    const increment=()=>{
        setcount(count+1)
    }
    return (
        <div className='count'>
            <div className="row">
                <div className="col">
                    <div className="btn-group" role="group" aria-label="Basic mixed styles example">
                        <button type="button" className="btn minus" onClick={decrement}>-</button>
                        <button type="button" className="btn count">{count}</button>
                        <button type="button" className="btn plus" onClick={increment}>+</button>
                    </div>
                </div>
                <div className="col">
                    <button className='cart'><i className="bi bi-cart3"></i><span>Add to cart</span></button>
                </div>
            </div>
        </div>
    )
}
