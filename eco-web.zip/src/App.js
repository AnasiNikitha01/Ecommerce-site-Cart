import './App.css';
import Data from './components/Data';
import Display from './components/Display';
import Navbar from './components/Navbar';

function App() {
  return (
    <div className="App">
        <Navbar/>
        <div className="row">
          <div className="col"><Display/></div>
          <div className="col"><Data/></div>
        </div>
    </div>
  );
}

export default App;
